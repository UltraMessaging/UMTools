/* 
 * _lbm.h
 *
 * Created on: Jun 30, 2016
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND INFORMATICA DISCLAIMS ALL WARRANTIES
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY IMPLIED WARRANTIES OF
 * NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 * PURPOSE.  INFORMATICA DOES NOT WARRANT THAT USE OF THE SOFTWARE WILL BE
 * UNINTERRUPTED OR ERROR-FREE.  INFORMATICA SHALL NOT, UNDER ANY CIRCUMSTANCES, BE
 * LIABLE TO LICENSEE FOR LOST PROFITS, CONSEQUENTIAL, INCIDENTAL, SPECIAL OR
 * INDIRECT DAMAGES ARISING OUT OF OR RELATED TO THIS AGREEMENT OR THE
 * TRANSACTIONS CONTEMPLATED HEREUNDER, EVEN IF INFORMATICA HAS BEEN APPRISED OF
 * THE LIKELIHOOD OF SUCH DAMAGES.
 *
 */
#ifndef _WIN32
#include <inttypes.h>
#endif

/* Types */
typedef unsigned int _lbm_uint_t;
typedef unsigned long int _lbm_ulong_t;
typedef unsigned short int _lbm_ushort_t;
typedef unsigned char _lbm_uchar_t;


typedef uint8_t _lbm_uint8_t;
typedef uint16_t _lbm_uint16_t;
typedef uint32_t _lbm_uint32_t;
typedef uint64_t _lbm_uint64_t;


#define _LBM_CONTEXT_INSTANCE_BLOCK_SZ 8
#define _LBM_TOPIC_RES_REQUEST_ADVERTISEMENT 0x04
#define _LBM_TOPIC_RES_REQUEST_QUERY 0x02
#define _LBM_TOPIC_RES_REQUEST_WILDCARD_QUERY 0x01
#define _LBM_TOPIC_RES_REQUEST_CONTEXT_QUERY 0x20
#define _LBM_TOPIC_RES_REQUEST_GW_REMOTE_INTEREST 0x40
#define _LBM_OTID_BLOCK_SZ 32
#define _LBM_CONTEXT_INSTANCE_BLOCK_SZ 8

/* Limits */
#define _LBM_MSG_MAX_SOURCE_LEN 128
#define _LBM_MSG_MAX_TOPIC_LEN 256
#define _LBM_MSG_MAX_STATE_LEN 32
#define _LBM_UME_MAX_STORE_STRLEN 24
#define _LBM_UMQ_MAX_QUEUE_STRLEN 256
#define _LBM_UMQ_MAX_TOPIC_STRLEN 256
#define _LBM_UMQ_MAX_APPSET_STRLEN 256
#define _LBM_MAX_CONTEXT_NAME_LEN 128
#define _LBM_MAX_EVENT_QUEUE_NAME_LEN 128
#define _LBM_MAX_UME_STORES 25
#define _LBM_UMQ_ULB_MAX_RECEIVER_STRLEN 32
#define _LBM_UMQ_MAX_INDEX_LEN 216
#define _LBM_UMQ_USER_NAME_LENGTH_MAX 127
#define _LBM_UMQ_PASSWORD_LENGTH_MAX 15
#define _LBM_UMM_NUM_SERVERS_MAX 16
#define _LBM_UMM_USER_NAME_LENGTH_MAX 100
#define _LBM_UMM_APP_NAME_LENGTH_MAX 100
#define _LBM_UMM_PASSWORD_LENGTH_MAX 100
#define _LBM_UMM_SERVER_LENGTH_MAX 32
#define _LBM_HMAC_BLOCK_SZ       20
#define _LBM_MAX_GATEWAY_NAME_LEN 128
#define _LBM_OTID_BLOCK_SZ 32
#define _LBM_CONTEXT_INSTANCE_BLOCK_SZ 8


/* UM Transport Types */
/*! Transport type TCP. */
#define _LBM_TRANSPORT_TYPE_TCP 0x00
/*! Transport type LBT-RU. */
#define _LBM_TRANSPORT_TYPE_LBTRU 0x01
/*! Transport type LBT-SMX. */
#define _LBM_TRANSPORT_TYPE_LBTSMX 0x4
/*! Transport type LBT-RM. */
#define _LBM_TRANSPORT_TYPE_LBTRM 0x10
/*! Transport type LBT-IPC. */
#define _LBM_TRANSPORT_TYPE_LBTIPC 0x40
/*! Transport type LBT-RDMA. */
#define _LBM_TRANSPORT_TYPE_LBTRDMA 0x20

typedef struct _lbm_transport_source_info_t_stct {
        /*! Type of transport. See _LBM_TRANSPORT_TYPE_*. */
        int type;
        /*! Source IP address. Applicable only to LBT-RM, LBT-RU, TCP, and LBT-RDMA. Stored in network order. */
        _lbm_uint32_t src_ip;
        /*! Source port. Applicable only to LBT-RM, LBT-RU, TCP, and LBT-RDMA. Stored in host order. */
        _lbm_ushort_t src_port;
        /*! Destination port. Applicable only to LBT-RM. Stored in host order. */
        _lbm_ushort_t dest_port;
        /*! Multicast group. Applicable only to LBT-RM. Stored in network order. */
        _lbm_uint32_t mc_group;
        /*! Transport ID. Applicable only to LBT-IPC. Stored in host order. */
        _lbm_uint32_t transport_id;
        /*! Session ID. Applicable to all transport. Stored in host order. */
        _lbm_uint32_t session_id;
        /*! Topic index. Applicable to all transports. Stored in host order. */
        _lbm_uint32_t topic_idx;
        /*! Transport index. Applicable to all transports. Stored in host order. */
        _lbm_uint32_t transport_idx;
        char tname[_LBM_MSG_MAX_TOPIC_LEN];
} _lbm_transport_source_info_t;


