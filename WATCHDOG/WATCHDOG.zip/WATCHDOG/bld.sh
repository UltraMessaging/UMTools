
cc -L/home/ibu/Desktop/UMP_6.7.1.4/Linux-glibc-2.5-x86_64/lib/ -I/home/ibu/Desktop/UMP_6.7.1.4/Linux-glibc-2.5-x86_64/include  -llbm -lm  -o lbm_watchdog lbm_watchdog.c lbmotid.c

#bld.sh  getopt.c  lbmotid.c  lbmrpckt.h  lbm_watchdog.c  local_lbm.h  verifymsg.c

